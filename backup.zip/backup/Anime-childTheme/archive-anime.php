
<?php get_header(); ?>

<body class="container--blog">
<div class="navigation" id="navbar">
 <a href="<?php echo site_url(''); ?>"><img class="navigation__logo" src="<?php echo get_template_directory_uri();?>/img/logo.png" alt="Moje-anime-logo" /></a>
 <nav class="navigation__nav">
   <ul class="navigation__list">
   <li class="navigation__item">
       <a href="<?php echo site_url(''); ?>" class="navigation__link">Strona główna</a>
     </li>
     <li class="navigation__item">
       <a href="<?php echo site_url('/kategorie'); ?>" class="navigation__link">Kategorie</a>
     </li>
    
   </ul>
   <!-- <button class="register__btn btn">
       Zarejestruj
     </button>
     <button class="login__btn btn">
       Zaloguj
     </button> -->
 </nav>
 <button class="menu" aria-label="Menu">
   <span class="menu__span"></span>
 </button>
 </div>
 <!-- news (banner) -->
   
<!-- <section class="news u--margin-bottom-10" id="news">
  <h2 class="main__heading">Anime</h2>
    <div class="articles--blog"> -->

    <h2>hellofrom archie -anime</h2>

<br>
<br>
<br>

<?php
while( have_posts()){
  the_post();

?>
       <h2><?php the_field('nazwa_anime'); ?></h2>
       <a href="<?php the_permalink();?>" class="odcinek">zobacz wiecej</a>

        <?php
}
wp_reset_query();
        ?>



<br>
<br>
<br>

<?php

// check if the repeater field has rows of data
//if( have_rows('pojemink') ):

 	// loop through the rows of data
   // while ( have_rows('pojemink') ) : the_row() ?>

<!-- <div class="container__seasons">
<div class="panel">
<h2 class="title"><?php// the_sub_field('sezon') ?></h2>

<div class="season">
<h3> <?php// the_sub_field('sezon') ?></h3>
<div class="odcinki">
<a href="<?php //the_permalink();?>" class="odcinek"><?php// the_sub_field('odcinek') ?></a>
</div>

</div>
</div>
</div> -->

<?php //endwhile; else : endif;?>
 
<!-- 
<div class="container__seasons">
<div class="panel">
<h2 class="title">tutuł</h2>
<div class="season">
<h3> Sezomny</h3>
<div class="odcinki">
              <a href="#" class="odcinek">odcinek1</a>
            <a href="#" class="odcinek">odcinek1</a>
            <a href="#" class="odcinek">odcinek1</a>
          </div>
        </div>
    </div>
 -->



<?php //if( have_rows('anime_repater')) : ?>

  <!-- <div class="container__seasons"> -->

  <?php //while(have_rows('anime_repater')): the_row();

  // $img = get_sub_field('img');
  // $title = get_sub_field('tytul');
  // $seasons = get_sub_field('sezony');
  // $episode = get_sub_field('odcinki');

  ?>

<!-- <div class="panel"> -->

  <!-- <h2 class="title">	<?php// echo $title; ?></h2> -->
		

      <!-- <?php// if( $seasons ): ?> -->
        <!-- <div class="season"> -->
        <!-- <h3><?php //if( have_rows($seasons)) : while(have_rows($seasons)): the_row();?> -->
        <?php// endwhile; ?>
        <?php //endif; ?>
        <!-- </h3> -->
        <!-- </div> -->
			<?php //endif; ?>
      <!-- <div class="odcinki"> -->

      <?php// if( $episode): ?>
        <!-- <div class="odcinki"> -->
        <!-- <a href="#" class="odcinek"><?php //echo $episode; ?></a> -->
        <!-- </div> -->
			<?php //endif; ?>
      <!-- </div> -->
    
  <?php //endwhile; ?>
  <!-- </div> -->
<?//php endif; ?>

<!-- <div class="panel"> -->






    
    
        
        
         
 

</div>
</section>

<script>

const epi = document.querySelectorAll(".season");
function toggleOpen() {
  this.classList.toggle("open");
}

epi.forEach(odcinki => odcinki.addEventListener("click", toggleOpen));

</script>

