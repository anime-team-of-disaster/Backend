
<?php get_header(); ?> 
<div class="navigation" id="navbar">
 <a href="<?php echo site_url(''); ?>"><img class="navigation__logo" src="<?php echo get_template_directory_uri();?>/img/logo.png" alt="Moje-anime-logo" /></a>
 <nav class="navigation__nav">
   <ul class="navigation__list">
     
     <li class="navigation__item">
       <a href="<?php echo site_url(''); ?>" class="navigation__link">Strona główna</a>
     </li>
     <li class="navigation__item">
       <a href="<?php echo site_url('/news'); ?>" class="navigation__link">Blog</a>
     </li>
     <li class="navigation__item">
       <a href="<?php echo site_url('/kategorie'); ?>" class="navigation__link">Kategorie</a>
     </li>
    
   </ul>
   <!-- <button class="register__btn btn">
       Zarejestruj
     </button>
     <button class="login__btn btn">
       Zaloguj
     </button> -->
 </nav>
 <button class="menu" aria-label="Menu">
   <span class="menu__span"></span>
 </button>
 </div>

<body class="contenier--post">

<div class="container__post">

<?php 

while(have_posts()){
    the_post();
    ?>

<h2><?php the_field('nazwa_anime'); ?></h2>

<?php

// Wyswietla repeater sezonów
if( have_rows('sezony') ):

 	// wyświetla containery
    while ( have_rows('sezony') ) : the_row();?>


<div class="container__seasons">
<div class="panel">
   
<?php

// wyświetla numer sezonów
if( have_rows('sezon') ):

 	// loop through the rows of data
    while ( have_rows('sezon') ) : the_row();?>


<h2 class="title"><?php the_sub_field('numer'); ?></h2>
<div class="season">
<div class="odcinki">


<?php

// wyświetla odcinki numer i link
if( have_rows('odcinek') ):

 	// loop through the rows of data
    while ( have_rows('odcinek') ) : the_row();?>

<a href="<?php the_sub_field('link'); ?>" class="odcinek"><?php  the_sub_field('odcinek_numer'); ?></a>
           
   <?php endwhile; else :endif;?>
</div>
  <?php endwhile; else :endif;?>
</div>
</div>     
<?php endwhile;else :endif;?>



<?php 
}
?>
</div>
</div>
</div>

<?php get_footer(); ?> 





<!-- 
<div class="post">
    <figure class="post__figure">
  <img class="post__img" src="<?php// echo// get_the_post_thumbnail_url(get_the_ID()); ?>">
  </figure>
  <h2>hello from single anime</h2>
<div class="post__info">
    <h2 class="post__heading"><?php //the_title(); ?></h2>
    <p class="post__author">Dodał <?php //the_author(); ?></p> 

    <div class="post__content">
     -->



