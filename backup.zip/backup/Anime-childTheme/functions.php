<?php

add_action('wp_enqueue_scripts', 'Anime_child_styles');

function Anime_child_styles(){

    wp_enqueue_style('parent-style', get_template_directory_uri() . '../style.css');
    // wp_enqueue_script( 'parent-anime', get_template_directory_uri() . 'js/anime.js', array (), 1.1, true);

};

// skrypty nie działają nie wiem czemu ?







