const epi = document.querySelectorAll(".season");

function toggleOpen() {
  this.classList.toggle("open");
}

epi.forEach(odcinki => odcinki.addEventListener("click", toggleOpen));
