<?php
/*
Plugin Name: Anime
Plugin URI: https://github.com/anime-team-of-disaster/Strefa-Anime
Description: Anime Custom Post Types and Taxonomies
Version: 0.1 
Author: Robert Purc
Author URI: https://github.com/RobertPurc
License: GPL2
Text Domain: anime
*/

//security to prevent access of php files 
if(! defined('ABSPATH')){
    exit;
}

function create_anime_cpt(){

    $labels = array(
        'name' => __('Anime', 'Post Type General Name', 'anime'),
        'singular_name' => __('anime','Post Type Singular Name', 'anime' ),
        'menu_name' => __('anime', 'anime'),
        'name_admin_bar' => __('anime', 'anime'),
        'archives' => __('anime Archives', 'anime'),
        'attributes' => __('Anime Attributes', 'anime'),
        'parent_item_colon' =>__('Parent Anime', 'anime'),
        'all_items' => __('All anime ', 'anime'),
        'add_new_item' => __('Add New anime', 'anime'),
        'add_new' => __('Add New', 'anime'),
        'new_item' => __('New Anime', 'anime'),
        'edit_item' => __('Edit Anime', 'anime'),
        'update_item' => __('Update Anime', 'anime'),
        'view_item' => __('View Anime', 'anime'),
        'view_items' => __('View Anime', 'anime'),
        'search_items' => __('Search Anime', 'anime'),
        'not_found' => __('Not Found Anime', 'anime'),
        'not_found_in_trash' => __('Not Found in Trash', 'anime'),
        'featured_image' => __('Featured Image', 'anime'),
        'set_featured_image' => __('Set Featured Image', 'anime'),
        'remove_featured_image' => __('Remove Featured Image', 'anime'),
        'use_featured_image' => __('Use as Featured Image', 'anime'),
        'insert_into_item' => __('Isert into anime', 'anime'),
        'uploaded_to_this_itme' => __('Uploaded To This Anime', 'anime'),
        'items_list' => __('Anime list', 'anime'),
        'items_list_navigation' => __('Anime list navigation', 'anime'),
        'filter_items_list' => __('filter Anime list', 'anime'),
    );

    
    $args = array(
        'label' => __('Anime', 'anime'),
        'description' => __('Anime odcinki', 'anime'),
        'labes' => $labels,
        'menu_icon' => 'dashicons-editor-video',
        'supports' => array('title', 'editior', 'thumbnail', 'revisions', 'author'),
        'taxonomies' => array('category', 'post_tag'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_postion' => 2,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' =>true,
        'has_archive' =>true,
        'hierarchical' => false,
        'exclude_from_search' => false,
        'show_in_rest' =>true,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'rewrite' => array('slug' => 'anime'),
    );
    register_post_type( 'anime', $args);
}

add_action( 'init', 'create_anime_cpt', 0 );

function rewrite_anime_flush(){
    create_anime_cpt();
    flush_rewrite_rules(  );

}
register_activation_hook( __FILE__,'rewrite_anime_flush' );
