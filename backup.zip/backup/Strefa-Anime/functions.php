<?php

function add_theme_scripts() {

    wp_enqueue_style( 'swiper', get_template_directory_uri() . '/css/swiper.css', array(), '1.1', 'all');
    // wp_enqueue_style('cdnCssSwiper', 'https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.1/css/swiper.min.css');
    wp_enqueue_style( 'style', get_stylesheet_uri() );
    wp_enqueue_style('google-fonts-lato', '//fonts.googleapis.com/css?family=Lato:300,400,700&display=swap&subset=latin-ext');
    wp_enqueue_style('google-fonts-sengwick', '//fonts.googleapis.com/css?family=Sedgwick+Ave&display=swap&subset=latin-ext');
    

    // wp_enqueue_script('swiperCdnJs', 'https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.1/js/swiper.js');
    //ew osobny folder ze stylami
    // wp_enqueue_style( 'style', get_template_directory_uri() . '/css/style.css', array(), '1.1', 'all');
    wp_enqueue_script( 'swiper', get_template_directory_uri() . '/js/swiper.js', array (), 1.1, true);
    wp_enqueue_script( 'main', get_template_directory_uri() . '/js/main.js', array (), 1.1, true);
    wp_enqueue_script( 'anime', get_template_directory_uri() . '/js/anime.js', array (), 1.1, true);
   
  
    
   
    
  }
  add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );



function sa_init(){
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('html5',
array('comment-list', 'comment-form', 'search-form')
);

}

add_action('after_setup_theme', 'sa_init');

//porejcts post type

function sa_custom_post_type(){
    register_post_type('OnGoing',
    array(
        'rewrite' => array('slug' => 'OnGoing'),
        'labels' => array(
            'name' => 'OnGoing',
            'singular_name' => 'Add New OnGoing',
            'edit_item' => 'Edit OnGoing'

        ),
        'menu-icon' => 'dashicons-clipboard',
        'public' => true,
        'has_archive' => true,
        'supports' => array(
            'title', 'thumbnail', 'editor',
        )
        ));
}

add_action('init', 'sa_custom_post_type');

 