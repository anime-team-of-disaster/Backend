<?php get_header(); ?>

<body class="container--blog">
<div class="navigation" id="navbar">
 <a href="<?php echo site_url(''); ?>"><img class="navigation__logo" src="<?php echo get_template_directory_uri();?>/img/logo.png" alt="Moje-anime-logo" /></a>
 <nav class="navigation__nav">
   <ul class="navigation__list">
   <li class="navigation__item">
       <a href="<?php echo site_url(''); ?>" class="navigation__link">Strona główna</a>
     </li>
     <li class="navigation__item">
       <a href="<?php echo site_url('/kategorie'); ?>" class="navigation__link">Kategorie</a>
     </li>
    
   </ul>
   <!-- <button class="register__btn btn">
       Zarejestruj
     </button>
     <button class="login__btn btn">
       Zaloguj
     </button> -->
 </nav>
 <button class="menu" aria-label="Menu">
   <span class="menu__span"></span>
 </button>
 </div>
 <!-- news (banner) -->
   
<section class="news u--margin-bottom-10" id="news">
  <h2 class="main__heading">Blog</h2>
    <div class="articles--blog">



<?php



while( have_posts()){
  the_post();

?>
        <article class="article ">
          <img class="article__img" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="" />
          <div class="article__info">
            <h2 class="article__heading"><?php echo the_title();?></h2>
            <p class="article__description">
             <?php echo wp_trim_words( get_the_excerpt(), 30); ?>
            </p>
            <div class="article__link--box">
              <a href="<?php the_permalink();?>" class="article__link ">Czytaj więcej</a>
            </div>
          </div>
        </article>
        <?php
}
wp_reset_query();
        ?>

</div>
</section>
<div class="pagination--blog">
<?php echo paginate_links(); ?>
</div>

