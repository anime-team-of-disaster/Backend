<?php get_header(); ?> 
<div class="navigation" id="navbar">
 <a href="<?php echo site_url(''); ?>"><img class="navigation__logo" src="<?php echo get_template_directory_uri();?>/img/logo.png" alt="Moje-anime-logo" /></a>
 <nav class="navigation__nav">
   <ul class="navigation__list">
     
     <li class="navigation__item">
       <a href="<?php echo site_url(''); ?>" class="navigation__link">Strona główna</a>
     </li>
     <li class="navigation__item">
       <a href="<?php echo site_url('/news'); ?>" class="navigation__link">Blog</a>
     </li>
     <li class="navigation__item">
       <a href="<?php echo site_url('/kategorie'); ?>" class="navigation__link">Kategorie</a>
     </li>
    
   </ul>
   <!-- <button class="register__btn btn">
       Zarejestruj
     </button>
     <button class="login__btn btn">
       Zaloguj
     </button> -->
 </nav>
 <button class="menu" aria-label="Menu">
   <span class="menu__span"></span>
 </button>
 </div>

<body class="contenier--post">
<div class="container__post">
<?php 

while(have_posts()){
    the_post();
    ?>

<div class="post">
    <figure class="post__figure">
  <img class="post__img" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>">
  </figure>
<div class="post__info">
    <h2 class="post__heading"><?php the_title(); ?></h2>
    <p class="post__author">Dodał <?php the_author(); ?></p> 

    <div class="post__content">
    <?php the_content();
   
}

?>
</div>

</div>
</div>

</div>

<?php get_footer(); ?> 



