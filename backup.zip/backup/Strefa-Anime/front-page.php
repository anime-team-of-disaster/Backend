<?php get_header(); ?>
<body class="container">
<div class="navigation" id="navbar">
 <a href="<?php echo site_url(''); ?>"><img class="navigation__logo" src="<?php echo get_template_directory_uri();?>/img/logo.png" alt="Moje-anime-logo" /></a>
 <nav class="navigation__nav">
   <ul class="navigation__list">
     <li class="navigation__item">
       <a href="#popular" class="navigation__link">Popularne anime</a>
     </li>
     <li class="navigation__item">
       <a href="#news" class="navigation__link">Newsy</a>
     </li>
     <li class="navigation__item">
       <a href="<?php echo site_url('/news'); ?>" class="navigation__link">Blog</a>
     </li>
     <li class="navigation__item">
       <a href="<?php echo site_url('/anime'); ?>" class="navigation__link">anime</a>
     </li>
     <li class="navigation__item last">
       <a href="#new" class="navigation__link">Nowości</a>
     </li>
   </ul>
   <!-- <button class="register__btn btn">
       Zarejestruj
     </button>
     <button class="login__btn btn">
       Zaloguj
     </button> -->
 </nav>
 <button class="menu" aria-label="Menu">
   <span class="menu__span"></span>
 </button>
 </div>

 
  <!-- header -->
  <header class="header" id="header">
    <div class="header__container">
      <h1 class="header__heading">Znajdz swoje anime</h1>
      <form action="" class="form">
        <input type="text" placeholder="Wyszukaj animu" class="form__input" name="search_text" id="search_text"  autocomplete="off" >
        <input type="button" value="szukaj" class="btn form__btn" />
        <div class="results" id="result">
        </div>
      </form>
    </div>

  </header>
  <!-- end header -->

  <!-- main  -->
  <main class="main">
  <!-- popular slider -->
  


<section id="popular" class="u--margin-bottom-10">
      <h2 class="main__heading">Popularne anime</h2>
      <!-- Slider main container -->
      <div class="swiper-container">
        <!-- Additional required wrapper -->
        <div class="swiper-wrapper">
          <!-- Slides -->
          <div class="swiper-slide">
            <div class="swiper-slide__box">
              <img class="swiper__img" src="<?php echo get_template_directory_uri();?>img/sao-card.jpg" alt="sao" />
              <div class="swiper__img--shadow">
                <button class="swiper__img__btn btn">Sprawdź</button>
              </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-slide__box">
              <img class="swiper__img" src="<?php echo get_template_directory_uri();?>img/sao-card.jpg" alt="sao" />
              <div class="swiper__img--shadow">
                <button class="swiper__img__btn btn">Sprawdź</button>
              </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-slide__box">
              <img class="swiper__img" src="<?php echo get_template_directory_uri();?>img/sao-card.jpg" alt="sao" />
              <div class="swiper__img--shadow">
                <button class="swiper__img__btn btn">Sprawdź</button>
              </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-slide__box">
              <img class="swiper__img" src="<?php echo get_template_directory_uri();?>img/sao-card.jpg" alt="sao" />
              <div class="swiper__img--shadow">
                <button class="swiper__img__btn btn">Sprawdź</button>
              </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-slide__box">
              <img class="swiper__img" src="<?php echo get_template_directory_uri();?>img/sao-card.jpg" alt="sao" />
              <div class="swiper__img--shadow">
                <button class="swiper__img__btn btn">Sprawdź</button>
              </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="swiper-slide__box">
              <img class="swiper__img" src="<?php echo get_template_directory_uri();?>img/sao-card.jpg" alt="sao" />
              <div class="swiper__img--shadow">
                <button class="swiper__img__btn btn">Sprawdź</button>
              </div>
            </div>
          </div>
        </div>
        <!-- If we need pagination -->
        <!-- <div class="swiper-pagination"></div> -->

        <!-- If we need navigation buttons -->
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
      </div>
    </section>









    <!-- news (banner) -->
   
<section class="news u--margin-bottom-10" id="news">
  <h2 class="main__heading">Newsy</h2>
    <div class="articles">



<?php

$args = array(
  'post_type' => 'post',
  'posts_per_page' => 2,
);

$blogposts = new WP_Query($args);

while($blogposts-> have_posts()){
  $blogposts->the_post();

?>
        <article class="article">
          <img class="article__img" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="" />
          <div class="article__info">
            <h2 class="article__heading"><?php echo the_title();?></h2>
            <p class="article__description">
             <?php echo wp_trim_words( get_the_excerpt(), 30); ?>
            </p>
            <div class="article__link--box">
              <a href="<?php the_permalink();?>" class="article__link ">Czytaj więcej</a>
            </div>
          </div>
        </article>
        <?php
}
wp_reset_query();
        ?>

</div>
</section>
<div class="pagination">
<?php echo paginate_links(); ?>
</div>



    



<section id="new" class="u--margin-bottom-10">
<h2 class="main__heading">Nowości Anime</h2>
<!-- Slider main container -->
<div class="swiper-container">
  <!-- Additional required wrapper -->
  <div class="swiper-wrapper">
    <!-- Slides -->
    <div class="swiper-slide">
      <div class="swiper-slide__box">
        <img class="swiper__img" src="img/sao-card.jpg" alt="sao" />
        <div class="swiper__img--shadow">
          <button class="swiper__img__btn btn">Sprawdź</button>
        </div>
      </div>
    </div>
    <div class="swiper-slide">
      <div class="swiper-slide__box">
        <img class="swiper__img" src="img/sao-card.jpg" alt="sao" />
        <div class="swiper__img--shadow">
          <button class="swiper__img__btn btn">Sprawdź</button>
        </div>
      </div>
    </div>
    <div class="swiper-slide">
      <div class="swiper-slide__box">
        <img class="swiper__img" src="img/sao-card.jpg" alt="sao" />
        <div class="swiper__img--shadow">
          <button class="swiper__img__btn btn">Sprawdź</button>
        </div>
      </div>
    </div>
    <div class="swiper-slide">
      <div class="swiper-slide__box">
        <img class="swiper__img" src="img/sao-card.jpg" alt="sao" />
        <div class="swiper__img--shadow">
          <button class="swiper__img__btn btn">Sprawdź</button>
        </div>
      </div>
    </div>
    <div class="swiper-slide">
      <div class="swiper-slide__box">
        <img class="swiper__img" src="img/sao-card.jpg" alt="sao" />
        <div class="swiper__img--shadow">
          <button class="swiper__img__btn btn">Sprawdź</button>
        </div>
      </div>
    </div>
    <div class="swiper-slide">
      <div class="swiper-slide__box">
        <img class="swiper__img" src="img/sao-card.jpg" alt="sao" />
        <div class="swiper__img--shadow">
          <button class="swiper__img__btn btn">Sprawdź</button>
        </div>
      </div>
    </div>
  </div>
  <!-- If we need pagination -->
  <!-- <div class="swiper-pagination"></div> -->

  <!-- If we need navigation buttons -->
  <div class="swiper-button-prev"></div>
  <div class="swiper-button-next"></div>
</div>
</section>



  </main>
  
  
<?php get_footer(); ?>






  <script src="https://unpkg.com/swiper/js/swiper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/cferdinandi/smooth-scroll@15.0/dist/smooth-scroll.polyfills.min.js"></script>

  
  <script src="js/main.js"></script>
