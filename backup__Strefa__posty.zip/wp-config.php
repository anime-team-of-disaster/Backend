<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'J9E}IairSBMUk9rHAcHLY6T<ni7s{JB<]Pfs4} <Ph&t0DPoH!Fdm9EMK]dZB/96' );

define( 'SECURE_AUTH_KEY',  'eEfe:,MYOb& ?O~&ilVoHeK?[(w+s]lK( WNQSM--Sv/8qQ9/U_G4A@Tk{8wPq`@' );

define( 'LOGGED_IN_KEY',    '}5NSP)82:$h,:M~kJ; -|st]LlcDudUQ!6$FK,~|f9XSmmJym$bwPBM2hz63X^4<' );

define( 'NONCE_KEY',        'YmY EH&T?T|><O1$QLSi<MZ.~M]HE|<L;P@?bcilNjo#/RX/uhx}6gN@87$RRYPE' );

define( 'AUTH_SALT',        'E9t<{0sEizKVZ|Ex}?Tn}y?]EX#CkPyLSEU9NnU*v8Ftq8mtU5d>|sc;?:jU0)M~' );

define( 'SECURE_AUTH_SALT', 'tk?r<(?pVj+A|u^jt}wj$j7 J%?E02k@*GNdTFc[]y3rm>T0y.jc,@1m&PP(9u)&' );

define( 'LOGGED_IN_SALT',   'S^@cF(`T0vT(w8 #zG7NqT:vaD]2P{Z-l;[q.]-J8xCM-6kC}<vG^wWnhhqSQfu%' );

define( 'NONCE_SALT',       ';9/o##EscW,,F` W/cpbyV_}x*}C(i_FHXJ,go,;JagW`Yl_Bnp0$ko@m5EioZ):' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

}


/** Sets up WordPress vars and included files. */

require_once( ABSPATH . 'wp-settings.php' );

